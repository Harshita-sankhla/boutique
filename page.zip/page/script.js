function changeImage(imageSrc) {
    document.getElementById('mainImage').src = imageSrc;
}